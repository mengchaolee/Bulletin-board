﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using MyModel_CodeFirst.Models;

namespace MyModel_CodeFirst.Controllers
{
    public class PostBooksController : Controller
    {
        private readonly GuestBookContext _context;

        public PostBooksController(GuestBookContext context)
        {
            _context = context;
        }

        // GET: PostBooks
        public async Task<IActionResult> Index()
        {
            var Books = await _context.Book.OrderByDescending(b => b.TimeStamp).ToListAsync();

            return View(Books);
        }

        //3.2.3 將PostBooksController中Details Action改名為Display(View也要改名字)
        public async Task<IActionResult> Display(long? id)
        {
            if (id == null || _context.Book == null)
            {
                return NotFound();
            }

            var book = await _context.Book
                .FirstOrDefaultAsync(m => m.GId == id);
            if (book == null)
            {
                return NotFound();
            }

            return View(book);
        }

        [Route("GuestBook/{title}")]
        public async Task<IActionResult> DisplayByTitle(string title,long? id)
        {
            if (id == null || _context.Book == null)
            {
                return NotFound();
            }

            var book = await _context.Book
                .FirstOrDefaultAsync(m => m.GId == id);
            if (book == null)
            {
                return NotFound();
            }

            return View("Display",book);
        }

        // GET: PostBooks/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: PostBooks/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Book book, IFormFile uploadPhoto)
        {
            //檔案處理
            if (uploadPhoto != null) 
            {
                if (uploadPhoto.ContentType == "image/jpeg" || uploadPhoto.ContentType == "image/png")
                {
                    var memoryStream = new MemoryStream();

                    uploadPhoto.CopyTo(memoryStream);

                    book.Photo= memoryStream.ToArray();
                    book.ImageType = uploadPhoto.ContentType;
                }
            }


            book.TimeStamp= DateTime.Now;
            ModelState.Remove("uploadPhoto");

            if (ModelState.IsValid)
            {
                _context.Add(book);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(book);
        }

        //3.4.2 在PostBooksController裡寫一個會發生例外的Action如下
        public IActionResult ExceptionTest()
        {
            int a = 0;
            int s = 100 / a;
            return View();
        }


        private bool BookExists(long id)
        {
          return (_context.Book?.Any(e => e.GId == id)).GetValueOrDefault();
        }
    }
}
