﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MyModel_CodeFirst.Models;
using Newtonsoft.Json;


namespace MyModel_CodeFirst.Controllers
{
    public class LoginController : Controller
    {
        //4.2.4 建立DbContext物件
        private readonly GuestBookContext _context;

        public LoginController(GuestBookContext context)
        {
            _context = context;
        }

        //4.2.5 建立Get與Post的Login Action
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Login(Login login)
        {
            if (login == null)
                return View();


            var result = await _context.Login.Where(x => x.Account == login.Account && x.Password == login.Password).FirstOrDefaultAsync();

            if(result==null)
            {
                ViewData["ErrorMsg"] = "帳號或密碼錯誤!!";
                return View(login);
            }

            //輸入的帳號或密碼正確的處理
            //進行登入成功的狀態保留,保留在sessio物件中

            HttpContext.Session.SetString("Manager", JsonConvert.SerializeObject(login));

            return RedirectToAction("Index","Books");
        }

        //4.4.1 在Login Controller加入Logout Action
        public IActionResult Logout()
        {
            HttpContext.Session.Remove("Manager");

            return RedirectToAction("Login");
        }

    }
}
