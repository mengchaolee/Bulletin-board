﻿using Microsoft.EntityFrameworkCore;

namespace MyModel_CodeFirst.Models
{

    //1.3.2 撰寫SeedData類別的內容

    //      (2)撰寫Book及ReBook資料表內的初始資料程式
    //      (3)撰寫getFileBytes，功能為將照片轉成二進位資料
    public class SeedData
    {
        //(1)撰寫靜態方法 Initialize(IServiceProvider serviceProvider)
        public static void Initialize(IServiceProvider serviceProvider)
        {
            //(2)撰寫Book及ReBook資料表內的初始資料程式

            using (var context = new GuestBookContext(serviceProvider.GetRequiredService<DbContextOptions<GuestBookContext>>()))
            {
                if (!context.Book.Any())
                {
                    context.Book.AddRange(
                         new Book
                         {
                             Title = "壽司",
                             Description = "排隊美食值得一吃!",
                             Photo = getFileBytes("SeedSourcePhoto/1.JPG"),
                             ImageType = "image/jpeg",
                             Author = "Jack",
                             TimeStamp = DateTime.Now
                         },
                               new Book
                               {
                                   Title = "PIZZA",
                                   Description = "比必X客好吃",
                                   Photo = getFileBytes("SeedSourcePhoto/2.JPG"),
                                   ImageType = "image/jpeg",
                                   Author = "Mary",
                                   TimeStamp = DateTime.Now
                               },
                               new Book
                               {
                                   Title = "草莓塔",
                                   Description = "新鮮現摘的草莓超大顆",
                                   Photo = getFileBytes("SeedSourcePhoto/3.jpg"),
                                   ImageType = "image/jpeg",
                                   Author = "王小花",
                                   TimeStamp = DateTime.Now
                               },
                               new Book
                               {
                                   Title = "漢堡",
                                   Description = "大俠愛吃漢堡包！",
                                   Photo = getFileBytes("SeedSourcePhoto/4.jpg"),
                                   ImageType = "image/jpeg",
                                   Author = "王小花",
                                   TimeStamp = DateTime.Now
                               },
                               new Book
                               {
                                   Title = "焦糖鬆餅",
                                   Description = "鬆軟可口",
                                   Photo = getFileBytes("SeedSourcePhoto/5.jpg"),
                                   ImageType = "image/jpeg",
                                   Author = "Jack",
                                   TimeStamp = DateTime.Now
                               }
                        );

                    context.SaveChanges();

                    context.ReBook.AddRange(
                                new ReBook
                                {
                                    Description = "我也覺得好吃！",
                                    Author = "小蘭",
                                    TimeStamp = DateTime.Now,
                                    GId = 1
                                },
                               new ReBook
                               {
                                   Description = "我不喜歡....",
                                   Author = "柯南",
                                   TimeStamp = DateTime.Now,
                                   GId = 1
                               },
                               new ReBook
                               {
                                   Description = "你最好餓死",
                                   Author = "小蘭",
                                   TimeStamp = DateTime.Now,
                                   GId = 1
                               },
                               new ReBook
                               {
                                   Description = "高麗菜這樣超好吃啊～",
                                   Author = "小英",
                                   TimeStamp = DateTime.Now,
                                   GId = 2
                               },
                               new ReBook
                               {
                                   Description = "口味似乎偏辣",
                                   Author = "阿狗",
                                   TimeStamp = DateTime.Now,
                                   GId = 3
                               },
                               new ReBook
                               {
                                   Description = "我還是喜歡生魚片的握壽司",
                                   Author = "嫩嫩",
                                   TimeStamp = DateTime.Now,
                                   GId = 4
                               },
                               new ReBook
                               {
                                   Description = "我也是喜歡生魚片的握壽司，但這個也不錯",
                                   Author = "王小花",
                                   TimeStamp = DateTime.Now,
                                   GId = 4
                               },
                               new ReBook
                               {
                                   Description = "三杯雞比較對味",
                                   Author = "芷若",
                                   TimeStamp = DateTime.Now,
                                   GId = 5
                               });
                    context.SaveChanges();
                }
            }


            //(3)撰寫getFileBytes，功能為將照片轉成二進位資料
            byte[] getFileBytes(string path)
            {
                FileStream fileOnDisk = new FileStream(path, FileMode.Open);

                byte[] fileBytes;

                using (BinaryReader br = new BinaryReader(fileOnDisk))
                {
                    fileBytes = br.ReadBytes((int)fileOnDisk.Length);
                }

                return fileBytes;

            }
        }
    }
}
